from transformers import BertTokenizer
import csv


def preprocess(dts):
    Tokenized_data = []

    # Read the dataset
    with open("Dataset/" + dts + "_whole_sentence.txt", "r", encoding='utf-8') as Data:
        datas = Data.readlines()

    # Initialize the tokenizer
    tz = BertTokenizer.from_pretrained("bert-base-cased")

    for i, data in enumerate(datas):
        print("i :", i)
        data = data.replace("\n", "")

        # Tokenize and append
        Tokenized_data.append(tz.tokenize(data))

    # Write to the CSV file ONCE after the loop finishes
    output_path = "Processed/Tokenized" + dts + "_data1.csv"
    with open(output_path, 'w', newline='', encoding='utf--8') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerows(Tokenized_data)

    return Tokenized_data





