
import re
import warnings
from pathlib import Path
import numpy as np
from gensim.models import Word2Vec
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from Main import Label

warnings.filterwarnings("ignore")


# -------------------------------------------------------
# Configuration
# -------------------------------------------------------
OUTPUT_DIR = Path("Processed")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

WORD2VEC_SIZE = 50
WORD2VEC_WINDOW = 5
WORD2VEC_MIN_COUNT = 1
WORD2VEC_EPOCHS = 20


# -------------------------------------------------------
# NLTK tokenizer
# -------------------------------------------------------
def tokenize_text(text):
    """Tokenize text into lowercase word tokens."""
    return re.findall(r"\b\w+\b", text.lower())


# -------------------------------------------------------
# Sentence length
# -------------------------------------------------------
def sentence_length(sentence):
    """Return the number of words in a sentence."""
    return len(tokenize_text(sentence))


# -------------------------------------------------------
# Bag of Words
# -------------------------------------------------------
def Bag_words(text, vectorizer=None):
    """
    Generate a binary Bag-of-Words vector.

    Pass a fitted vectorizer to maintain the same vocabulary
    across all sentences and datasets.
    """
    if vectorizer is None:
        vectorizer = CountVectorizer(
            binary=True,
            tokenizer=tokenize_text,
            token_pattern=None,
            lowercase=False
        )
        vectorizer.fit([text])

    return vectorizer.transform([text]).toarray()[0].astype(float)


# -------------------------------------------------------
# TF-IDF
# -------------------------------------------------------
def TF_IDF(text, vectorizer=None):
    """
    Return the TF-IDF vector for a sentence.

    A fitted corpus-level vectorizer should be supplied when
    processing a complete dataset.
    """
    if vectorizer is None:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            tokenizer=tokenize_text,
            token_pattern=None,
            lowercase=False
        )
        vectorizer.fit([text])

    return vectorizer.transform([text]).toarray()[0].astype(float)


# -------------------------------------------------------
# Word2Vec
# -------------------------------------------------------
def train_word2vec(sentences):
    """
    Train Word2Vec using the sentences in the supplied corpus.
    """
    tokenized_sentences = [
        tokenize_text(sentence)
        for sentence in sentences
        if tokenize_text(sentence)
    ]

    if not tokenized_sentences:
        return None

    model = Word2Vec(
        sentences=tokenized_sentences,
        vector_size=WORD2VEC_SIZE,
        window=WORD2VEC_WINDOW,
        min_count=WORD2VEC_MIN_COUNT,
        workers=1,
        seed=42,
        epochs=WORD2VEC_EPOCHS
    )

    return model


def word2vec_feat(text, model=None):
    """
    Return the mean of the Word2Vec embeddings of the words
    in a sentence. Output dimension is WORD2VEC_SIZE.
    """
    tokens = tokenize_text(text)

    if model is None or not tokens:
        return np.zeros(WORD2VEC_SIZE, dtype=float)

    vectors = [
        model.wv[word]
        for word in tokens
        if word in model.wv
    ]

    if not vectors:
        return np.zeros(WORD2VEC_SIZE, dtype=float)

    return np.mean(vectors, axis=0).astype(float)


# -------------------------------------------------------
# Sentence-to-sentence similarity
# -------------------------------------------------------
def similarity_matrix(sentences, tfidf_vectorizer):

    if not sentences:
        return np.zeros((0, 0), dtype=float)

    vectors = tfidf_vectorizer.transform(sentences)
    matrix = cosine_similarity(vectors)

    # A sentence is not compared with itself.
    np.fill_diagonal(matrix, 0.0)

    return matrix


def sentence_similarity_features(sentences, tfidf_vectorizer):

    matrix = similarity_matrix(sentences, tfidf_vectorizer)
    count = len(sentences)

    if count <= 1:
        return np.zeros(count, dtype=float)

    return matrix.sum(axis=1) / (count - 1)



# Read text lines

def read_sentences(data_path):

    with open(data_path, "r", encoding="utf-8") as file:
        sentences = [
            line.strip()
            for line in file
            if line.strip()
        ]

    return sentences

# Extract features

def ext_fea(sentences, dts):


    print(f"\nDataset: {dts}")
    print(f"Number of sentences: {len(sentences)}")

    # Fit vocabulary and IDF across all sentences in this file.
    bow_vectorizer = CountVectorizer(
        binary=True,
        tokenizer=tokenize_text,
        token_pattern=None,
        lowercase=False
    )

    tfidf_vectorizer = TfidfVectorizer(
        stop_words="english",
        tokenizer=tokenize_text,
        token_pattern=None,
        lowercase=False
    )

    bow_vectorizer.fit(sentences)
    tfidf_vectorizer.fit(sentences)

    # Train Word2Vec on the available corpus.
    w2v_model = train_word2vec(sentences)

    # Calculate similarity against the other sentences.
    similarity_values = sentence_similarity_features(
        sentences, tfidf_vectorizer
    )

    Feature = []

    for i, sentence in enumerate(sentences):
        print(f"Processing sentence {i + 1}/{len(sentences)}")

        bow_vector = Bag_words(sentence, bow_vectorizer)
        tfidf_vector = TF_IDF(sentence, tfidf_vectorizer)
        w2v_vector = word2vec_feat(sentence, w2v_model)

        # Scalar summaries of the respective representations.
        f1 = float(np.mean(bow_vector))
        f2 = float(np.mean(tfidf_vector))
        f3 = float(np.mean(w2v_vector))

        # Sentence length is already a scalar.
        f4 = float(sentence_length(sentence))

        # Mean similarity to other sentences.
        f5 = float(similarity_values[i])

        Feature.append([f1, f2, f3, f4, f5])

    Feature = np.asarray(Feature, dtype=np.float32)

    label = Label.class_(sentence)  # target data
    label = np.array(label)

    return Feature,label


