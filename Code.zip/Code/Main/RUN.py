import Bert_Tokenization, Feature_extraction
from Proposed_CWSA_based_HPCFH_Net import Proposed_run



def callmain(dts, lr):

    PRE, REC, FM, ROU = [], [], [], []

    O_Data = open("Dataset/" + dts + "_whole_sentence.txt", "r", encoding='utf-8')      # Read Input Dataset
    datas = O_Data.readlines()

    Tokenized_Data = Bert_Tokenization.preprocess(dts)                                # Tokenized data

    Feature, Label = Feature_extraction.ext_fea(Tokenized_Data, dts)       # Feature Data and target

    print("\n... Proposed Method Running ...")
    Proposed_run.call_method(datas, Feature, Label, lr, PRE, REC, FM, ROU)      # Proposed Model


    return PRE, REC, FM, ROU
