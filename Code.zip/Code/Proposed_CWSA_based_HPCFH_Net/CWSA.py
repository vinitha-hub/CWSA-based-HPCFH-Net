import random
import numpy as np
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning)


def Wave_search():

    def initial_soln(n, lb, ub, M):
        soln = []
        for i in range(n):
            t = []
            for j in range(M):
                x = np.random.uniform()
                t.append(lb + x * (ub - lb))  # Equation 4
            soln.append(t)
        return soln

    def fitness(soln):
        Fit = []
        for i in range(len(soln)):
            F = 0
            for j in range(len(soln[i])):
                hr = np.random.random()
                F += soln[i][j] * hr
            Fit.append(F)
        return Fit

    def val(soln):
        Fit = []
        for i in range(len(soln)):
            hr = np.random.random()
            F = soln[i] * hr
            Fit.append(F)
        return Fit

    def Global_exploration(W, Fitness, N, M):
        r1 = np.random.uniform(0, 1)            # random number from 0 to 1
        f_mean = np.average(Fitness)            # average of the fitness values of all the particles

        W_new = []
        for i in range(N):
            t = []
            for j in range(M):
                W_min = np.min(W[i][j])
                W_max = np.max(W[i][j])
                t.append(W_min + r1 * (W_max - W_min))          # Equation 5
            W_new.append(t)

        F_new = fitness(W_new)

        for k in range(len(F_new)):
            if F_new[k] <= f_mean:
                W[k] = W_new[k]                                  # Equation 6
            else:
                W[k] = W[k]

        return W, F_new

    def Local_exploitation(W, W_best, t, T, Fitness, N):

        sigma = -(5*t / (T-2)) / (np.sqrt(25 * (np.sqrt((5*t / (T-2))))) + 0.7)   # waveform size control coefficients
        sigma = sigma+1

        f_max = np.max(Fitness)

        W_new = []
        for i in range(len(W)):
            w_new = (W_best + (np.subtract(W[i], W_best)) * (1+i)) / sigma        # Equation 7
            W_new.append(w_new)

        F_new = fitness(W_new)
        epsilon = np.power(10, 6)
        alpha = 0.45
        Delta0 = 0.6 + (1.2-0.5) * np.sin((t*np.pi)/2*T)
        Delta1 = 0.7 + (1.2-0.5) * np.sin((t*np.pi)/2*T)
        Delta2 = 0.8 + (1.2-0.5) * np.sin((t*np.pi)/2*T)
        Eta = np.random.uniform()
        r2 = random.uniform(0, 1)
        r3 = random.uniform(0, 1)
        r4 = random.uniform(0, 1)
        r5 = random.uniform(0, 1)
        Lamda = (2*t/T-0.7) / (0.78+abs(2*t/T-0.7)) + 1*r2

        W_new1 = []
        for k in range(len(F_new)):
            if F_new[k] <= f_max:
                W_new1.append(W_new[k])                 # Equation 8

                # Reflect electromagnetic waves
                W_e_plus = W_new1[k] + epsilon
                W_e_minus = W_new1[k] - epsilon
                g = (np.subtract(val(W_e_plus), val(W_e_minus))) / (2*epsilon)      # Equation 9
                W_new1[k] = W_new1[k] - g*alpha                                     # Equation 10

                # Receive electromagnetic waves
                if r5 <= 0.7:
                    W_new1[k] = W_new1[k] + Delta0*r2*(W_best-W_new1[k]) + Eta*np.cos(np.pi/N) * \
                                (W_best - W_new1[k])                                # Equation 11
                else:
                    # W_new1[k] = W_new1[k] + Lamda*r3*(W_best-W_new1[k]) + (0.5*r4)*(1-Lamda) * (W_best - W_new1[k])
                    W_new1[k] = (Delta0 + Delta1*W_new1[k] + Delta2*W_new1[k] + Delta1*F_new[k] + Delta2*F_new[k]) * \
                                (1 - Lamda*r3 - 0.5*r4*(1-Lamda)) + (Lamda*r3*np.mean(W_best) +
                                 0.5*r4*(1-Lamda)*np.mean(W_best))                          # Equation update

            else:
                W_new1.append(W[k])

        Fitness1 = fitness(W_new1)
        for l in range(len(Fitness1)):
            if Fitness1[l] <= Fitness[l]:
                W[l] = W_new1[l]
            else: W[l] = W[l]

        return W

    # Initialization
    N = 10                  # number of particles
    T = 100                 # Maximum Iterations
    d = 10                  # dimension of the problem
    t = 0
    lb, ub = 1, 10          # lower and upper boundaries of the search space

    W = initial_soln(N, lb, ub, d)              # Using Eq. (4) to initialize group position
    Fitness = fitness(W)                        # Fitness of position
    best = np.argmin(Fitness)                   # Index of Best Fit
    best_soln = W[best]                         # Best position

    while t < T:

        # Rank the fitness values and find the current best individual position
        for i in range(1, N):
            # update group position
            W, Fitness = Global_exploration(W, Fitness, N, d)

        for j in range(1, N):
            W = Local_exploitation(W, best_soln, t, T, Fitness, N)

        t = t + 1

    Fitness_new = fitness(W)                        # Fitness of position
    best = np.argmin(Fitness_new)                   # Index of Best Fit
    W_best = W[best]                                # Optimal Position
    best_val = np.mean(W_best)

    return best_val
