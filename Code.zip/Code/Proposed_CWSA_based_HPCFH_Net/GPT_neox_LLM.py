from transformers import GPTNeoXTokenizerFast, pipeline
import warnings
warnings.filterwarnings("ignore")
# Load GPT_neox LLM Model
tokenizer = GPTNeoXTokenizerFast.from_pretrained("EleutherAI/gpt-neox-20b")
model = pipeline("summarization")


def llm_model(Text):

    trained_text = model(Text)
    trained_text = trained_text["summary_text"]

    input_ids = tokenizer(trained_text, return_tensors="pt").input_ids
    # Summarized Text
    generated_text = tokenizer.decode(input_ids, skip_special_tokens=True)

    abs_text = generated_text.split(".")

    return abs_text

