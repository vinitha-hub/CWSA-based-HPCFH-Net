import numpy as np


def jaccard_similarity(sent1, sent2):
    """Calculates the Jaccard similarity between two sentences."""

    # Tokenize sentences and convert to sets
    set1 = set(sent1.lower().split())
    set2 = set(sent2.lower().split())

    # Calculate intersection and union
    intersection = set1.intersection(set2)
    union = set1.union(set2)

    # Calculate Jaccard similarity
    jaccard_coef = len(intersection) / len(union)

    return jaccard_coef


def similarity_score(Data):
    W = []
    for sen in Data:
        temp = []
        for sen1 in Data:
            sentence1 = sen
            sentence2 = sen1
            similarity = jaccard_similarity(sentence1, sentence2)       # weight computation(wij)
            temp.append(similarity)
        W.append(temp)

    # Find Degree Centrality
    Score = []
    for i in range(len(W)):
        CD = np.sum(W[i])      # degree centrality CD(vi) of a sentence
        Score.append(CD)

    return Score
