import os, string
import numpy as np
import pandas as pd, nltk
nltk.download('stopwords')
nltk.download('wordnet')
from nltk import tokenize
from Proposed_CWSA_based_HPCFH_Net import CWSA
import warnings
from Proposed_CWSA_based_HPCFH_Net.sentence_scoring import *
warnings.filterwarnings("ignore", category=SyntaxWarning)
from keras.models import Model
from keras import backend as K
from nltk.corpus import stopwords
from keras.layers import Layer
from keras.optimizers import Adam as Opt
from nltk.stem import WordNetLemmatizer
from Proposed_CWSA_based_HPCFH_Net.Keras_preprocessing.keras_preprocessing.text import Tokenizer
from keras import initializers as initializers
import logging, os
logging.disable(logging.WARNING)
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
from keras.layers import Dense, Input, Embedding, Dropout, GRU, Bidirectional, TimeDistributed
from keras.utils import plot_model
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'


# Attention layer
class AttentionLayer(Layer):
    def __init__(self, attention_dim, return_coefficients=False, **kwargs):
        # Initializer
        self.supports_masking = True
        self.return_coefficients = return_coefficients
        self.init = initializers.get('glorot_uniform')  # initializes values with uniform distribution
        self.attention_dim = attention_dim
        super(AttentionLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        # Builds all weights
        # W = Weight matrix, b = bias vector, u = context vector
        assert len(input_shape) == 3
        self.W = K.variable(self.init((input_shape[-1], self.attention_dim)))
        self.b = K.variable(self.init((self.attention_dim,)))
        self.u = K.variable(self.init((self.attention_dim, 1)))
        self._trainable_weights = [self.W, self.b, self.u]
        super(AttentionLayer, self).build(input_shape)

    def compute_mask(self, input, input_mask=None):
        return None

    def call(self, hit, mask=None):
        # Here, the actual calculation is done
        uit = K.bias_add(K.dot(hit, self.W), self.b)
        uit = K.tanh(uit)

        ait = K.dot(uit, self.u)
        ait = K.squeeze(ait, -1)
        ait = K.exp(ait)

        if mask is not None:
            ait *= K.cast(mask, K.floatx( ))

        ait /= K.cast(K.sum(ait, axis=1, keepdims=True) + K.epsilon( ), K.floatx( ))
        ait = K.expand_dims(ait)
        weighted_input = hit * ait

        if self.return_coefficients:
            return [K.sum(weighted_input, axis=1), ait]
        else:
            return K.sum(weighted_input, axis=1)

    def compute_output_shape(self, input_shape):
        if self.return_coefficients:
            return [(input_shape[0], input_shape[-1]), (input_shape[0], input_shape[-1], 1)]
        else:
            return input_shape[0], input_shape[-1]


def Call_HAN(O_data, Data, label, tr):

    dim = len(Data)
    data = np.array(O_data)

    articles = []
    for i in range(len(data)):
        articles.append((data[i], label[i]))
    data_df = pd.DataFrame(data=articles, columns=['Text', "Category"])

    def cleanString(review, stopWords):
        lemmatizer = WordNetLemmatizer()
        returnString = ""
        sentence_token = tokenize.sent_tokenize(review)
        idx_list = []
        for j in range(len(sentence_token)):
            single_sentence = tokenize.word_tokenize(sentence_token[j])
            sentences_filtered = [(idx, lemmatizer.lemmatize(w.lower())) for idx, w in enumerate(single_sentence)
                                  if w.lower() not in stopWords and w.isalnum()]
            idx_list.append([x[0] for x in sentences_filtered])
            word_list = [x[1] for x in sentences_filtered]
            returnString = returnString + ' '.join(word_list) + ' . '

        return returnString, idx_list

    def split_df(dataframe, column_name, training_split=0.6, validation_split=0.2, test_split=0.2):
        if training_split + validation_split + test_split != 1.0:
            raise ValueError('Split paramter sum should be 1.0')

        total = len(dataframe.index)

        train = dataframe.reset_index().groupby(column_name).apply(lambda x: x.sample(frac=training_split)) \
            .reset_index(drop=True).set_index('index')
        train = train.sample(frac=1)
        temp_df = dataframe.drop(train.index)
        validation = temp_df.reset_index().groupby(column_name) \
            .apply(lambda x: x.sample(frac=validation_split / (test_split + validation_split))) \
            .reset_index(drop=True).set_index('index')
        validation = validation.sample(frac=1)
        test = temp_df.drop(validation.index)
        test = test.sample(frac=1)
        return train, validation, test

    def wordToSeq(text, word_index, max_sentences, max_words, max_features):
        sentences = tokenize.sent_tokenize(text)
        data = np.zeros((max_sentences, max_words), dtype='int32')
        for j, sent in enumerate(sentences):
            if j < max_sentences:
                wordTokens = tokenize.word_tokenize(sent.rstrip('.'))
                wordTokens = [w for w in wordTokens]
                k = 0
                for _, word in enumerate(wordTokens):
                    try:
                        if k < max_words and word_index[word] < max_features:
                            data[j, k] = word_index[word]
                            k = k + 1
                    except:
                        pass
        return data

    def to_categorical(series, class_dict):
        n_classes = len(class_dict)
        new_dict = {}
        for key, value in class_dict.items():
            cat_list = [0] * n_classes
            cat_list[key] = 1
            new_dict[key] = cat_list
        y_cat = []
        for key, value in series.items():
            y_cat.append(new_dict[value])
        return np.array(y_cat)


    """
    Compute average number of words in each sentence and average number of sentences in each document.
    """
    n_sent = 0
    n_words = 0
    for i in range(data_df.shape[0]):
        d = data_df.loc[i, 'Text']
        sent = tokenize.sent_tokenize(data_df.loc[i, 'Text'])

        for satz in sent:
            n_words += len(tokenize.word_tokenize(satz))
        n_sent += len(sent)

    # Parameters
    MAX_FEATURES = Data.shape[-1]  # maximum number of unique words that should be included in the tokenized word index
    MAX_SENTENCE_NUM = len(data_df)  # maximum number of sentences in one document
    MAX_WORD_NUM = dim  # maximum number of words in each sentence
    EMBED_SIZE = dim  # vector size of word embedding

    # Data Preprocessing
    """
    Cleans raw data using the cleanString() function from above.
    English stopwords are used from nltk library.
    Cleaned dataset is saved in 'data_cleaned' pandas dataframe.
    Labels are converted to numbers,
    """
    articles = []
    n = data_df['Text'].shape[0]
    col_number = data_df.columns.get_loc('Text')
    stopWords = set(stopwords.words('english'))
    data_cleaned = data_df.copy()

    for i in range(n):
        temp_string, idx_string = cleanString(data_df.iloc[i, col_number], stopWords)
        articles.append(temp_string)

    data_cleaned.loc[:, 'Text'] = pd.Series(articles, index=data_df.index)
    data_cleaned.loc[:, 'Category'] = pd.Categorical(data_cleaned.Category)
    data_cleaned['Category'] = data_cleaned['Category'].astype("category")
    data_cleaned['Code'] = data_cleaned.Category.cat.codes

    categoryToCode = dict(enumerate(data_cleaned['Category'].cat.categories))

    # Tokenization
    """
    Using the keras Tokenizer class a word index is built.
    The most 'MAX_FEATURES' used words are tokenized to a number.
    this dictionary is saved in word_index
    """
    texts = []
    n = data_cleaned['Text'].shape[0]
    for i in range(n):
        s = data_cleaned['Text'].iloc[i]
        s = ' '.join([word.strip(string.punctuation) for word in s.split() if word.strip(string.punctuation) is not ""])
        texts.append(s)

    tokenizer = Tokenizer(num_words=MAX_FEATURES, lower=True, oov_token=None)
    tokenizer.fit_on_texts(texts)
    word_index = tokenizer.word_index

    # Load word vectors
    embeddings_index = {}
    f = open(os.path.join(os.getcwd(), 'glove.txt'), encoding='UTF-8')

    f1 = f.readlines()
    for i in range(len(f1)):
        if f1[i] == '\n':
            i = i + 1
        else:
            values = f1[i].split()
            word = values[0]
            coefs = np.asarray(values[1:])
            embeddings_index[word] = coefs
    f.close()

    # Search words in our word index in the pre-trained dataset
    # Create an embedding matrix for our bbc dataset
    min_wordCount = 0
    absent_words = 0
    small_words = 0
    EMBED_SIZE = len(coefs)
    embedding_matrix = np.zeros((len(word_index) + 1, EMBED_SIZE))
    word_counts = tokenizer.word_counts

    for word, i in word_index.items():
        if word_counts[word] > min_wordCount:
            embedding_vector = embeddings_index.get(word)
            if embedding_vector is not None:
                # words not found in embedding index will be all-zeros.
                embedding_matrix[i] = embedding_vector
            else:
                absent_words += 1
        else:
            small_words += 1

    # Splitting Data Set
    """
    Split Pandas Dataframe into train, validation and test set.
    Convert data to keras conforming form
    """
    tr, v, tt = tr, 0, (1-tr)
    train, validation, test = split_df(data_cleaned, 'Code', tr, v, tt)

    # Test
    paras = []
    for i in range(test['Text'].shape[0]):
        sequence = wordToSeq(test['Text'].iloc[i], word_index, MAX_SENTENCE_NUM, MAX_WORD_NUM, MAX_FEATURES)
        paras.append(sequence)
    x_test = np.array(paras)
    y_test = to_categorical(test['Code'], categoryToCode)

    # Train
    paras = []
    for i in range(train['Text'].shape[0]):
        sequence = wordToSeq(train['Text'].iloc[i], word_index, MAX_SENTENCE_NUM, MAX_WORD_NUM, MAX_FEATURES)
        paras.append(sequence)
    x_train = np.array(paras)
    y_train = to_categorical(train['Code'], categoryToCode)

    # HAN MODEL
    """
    Create Keras functional model for hierarchical attention network
    """

    embedding_layer = Embedding(len(word_index) + 1, EMBED_SIZE, weights=[embedding_matrix],
                                input_length=MAX_WORD_NUM, trainable=False, name='word_embedding')

    # Words level attention model
    word_input = Input(shape=(MAX_WORD_NUM,), dtype='int32', name='word_input')
    word_sequences = embedding_layer(word_input)
    word_gru = Bidirectional(GRU(50, return_sequences=True), name='word_gru')(word_sequences)
    word_dense = Dense(dim, activation='relu', name='word_dense')(word_gru)
    word_att, word_coeffs = AttentionLayer(EMBED_SIZE, True, name='word_attention')(word_dense)
    wordEncoder = Model(inputs=word_input, outputs=word_att)

    # Sentence level attention model
    sent_input = Input(shape=(Data.shape[1], MAX_WORD_NUM), dtype='float32', name='sent_input')
    sent_encoder = TimeDistributed(wordEncoder, name='sent_linking')(sent_input)
    sent_gru = Bidirectional(GRU(50, return_sequences=True), name='sent_gru')(sent_encoder)
    sent_dense = Dense(100, activation='relu', name='sent_dense')(sent_gru)
    sent_att, sent_coeffs = AttentionLayer(EMBED_SIZE, return_coefficients=True, name='sent_attention')(sent_dense)
    sent_drop = Dropout(0.5, name='sent_dropout')(sent_att)
    preds = Dense(len(np.unique(test['Code'])), activation='softmax', dtype='float32')(sent_drop)

    # Model compile
    model = Model(sent_input, preds)
    model.compile(loss='binary_crossentropy', optimizer=Opt(learning_rate=CWSA.Wave_search()),metrics=['acc'])                                                              # CSWA update
    # plot_model(model, to_file='model_HAN.png', show_shapes=True, show_layer_names=True)

    W = model.get_weights()

    model.fit(x_train, y_train, batch_size=32, epochs=10, verbose=0)
    Pred = model.predict(x_test)

    Y1 = []
    for i in range(len(Pred)):
        y = Pred[i] * W
        Y1.append(y)

    return Y1
