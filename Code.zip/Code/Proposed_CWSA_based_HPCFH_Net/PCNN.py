from keras.layers import Embedding
from keras.models import Model
from keras.layers import Flatten, Conv1D, MaxPooling1D, AveragePooling1D, concatenate, Input, Dropout
from Proposed_CWSA_based_HPCFH_Net.sentence_scoring import *
from keras.optimizers import Adam
from Proposed_CWSA_based_HPCFH_Net import CWSA
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'


def model(output_dim=8, max_length=50, y_dim=5, num_filters=5, filter_sizes=[3, 5], pooling='max', pool_padding='valid',
          dropout=0.5):

    embed_input = Input(shape=(max_length,))
    x = Embedding(5, output_dim, input_length=max_length)(embed_input)

    pooled_outputs = []
    for i in range(len(filter_sizes)):
        conv = Conv1D(num_filters, kernel_size=filter_sizes[i], padding='valid', activation='relu')(x)
        if pooling == 'max':
            conv = MaxPooling1D(pool_size=max_length - filter_sizes[i] + 1, strides=1, padding=pool_padding)(conv)
        else:
            conv = AveragePooling1D(pool_size=max_length - filter_sizes[i] + 1, strides=1, padding=pool_padding)(conv)
        pooled_outputs.append(conv)
    merge = concatenate(pooled_outputs)

    x = Flatten()(merge)
    x = Dropout(dropout)(x)
    predictions = Dense(y_dim, activation='softmax')(x)  # TEST

    model = Model(inputs=embed_input, outputs=predictions)

    return model


def call_model(Feature, Label, tr, Y1):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    PCNN = model(output_dim=16, max_length=x_train.shape[1], y_dim=1, filter_sizes=[3, 4, 5], pooling='max', dropout=0.5)

    PCNN.compile(optimizer=Adam(learning_rate=CWSA.Wave_search()),
                 loss='binary_crossentropy', metrics=['acc'])

    W = PCNN.get_weights()
    PCNN.fit(x_train, y_train, epochs=10, batch_size=32, verbose=0)
    Pred = PCNN.predict(x_test)

    Y2 = []
    for i in range(len(Y1)):
        Pred[i] = Pred[i] * W
        y = Pred[i] * Y1[i]
        Y2.append(y)
    return Y2, y_test

