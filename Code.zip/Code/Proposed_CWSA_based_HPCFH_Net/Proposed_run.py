import numpy as np
from Proposed_CWSA_based_HPCFH_Net import HAN
from Proposed_CWSA_based_HPCFH_Net import PCNN
import evaluate
from sklearn.linear_model import LogisticRegression
from Proposed_CWSA_based_HPCFH_Net import sentence_scoring
from Proposed_CWSA_based_HPCFH_Net import Graph_based_summarization


def call_method(O_data, Feature, Label, lr, PRE, REC, FM, ROU):

    # HAN model
    Y1 = HAN.Call_HAN(O_data, Feature, Label, lr)

    # PCNN Model
    Y2, y_test = PCNN.call_model(Feature, Label, lr, Y1)

    # Harmonic Analysis
    Y3 = []
    # cosine calculation
    A = (1 + 2 * (np.cos(np.pi))) / 2

    for i in range(len(Y2)):
        y3 = abs(Y1[i] * A - Y2[i])
        Y3.append(y3)
    Y3 = np.array(Y3)

    model = LogisticRegression()
    model.fit(Y3, y_test)
    Score1 = model.coef_

    # Metrics Calculation
    tp, tn, fn, fp= 0, 0, 0, 0
    uni = np.unique(Label)
    target = y_test

    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(Y3)):
            val_scalar = Y3[i]

            if (target[i] == c and val_scalar == c):
                tp += 1
            elif (target[i] != c and val_scalar != c):
                tn += 1
            elif (target[i] == c and val_scalar != c):
                fn += 1
            elif (target[i] != c and val_scalar == c):
                fp += 1


    pre = tp / (tp + fp)
    recall = tp / (tp + fn)
    fm = (2 * tp) / ((2 * tp) + fp + fn)


    PRE.append(pre * 100)
    REC.append(recall * 100)
    FM.append(fm * 100)

    # ----------------------------- Graph based extractive text summarization -----------------------------
    Score2 = Graph_based_summarization.similarity_score(O_data)

    # Sentence scoring using fuzzy logic concept
    Extracted_text = sentence_scoring.score_fuse(Score1, Score2, target, O_data)

    print("###### Abstractive Summarization ######\n")
    # Abstractive summarization using GPT_Neox_LLM model
    from Proposed_CWSA_based_HPCFH_Net import GPT_neox_LLM

    Abstractive_text = []
    for i in range(len(Extracted_text)):
        # print("Extractive summary :\n", Extracted_text[i])
        Ab_text = GPT_neox_LLM.llm_model(Extracted_text[i])
        # print("Abstractive summary :\n", Ab_text)
        Abstractive_text.append(Ab_text)

    rouge = evaluate.load('rouge')
    rouge1 = rouge.compute(predictions=Extracted_text, references=Abstractive_text)
    rouge1 = rouge1.get("rouge1")
    ROU.append(rouge1*100)

    return PRE, REC, FM, ROU
