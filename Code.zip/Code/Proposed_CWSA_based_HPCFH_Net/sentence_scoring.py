import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import logging

logging.getLogger('tensorflow').disabled = True
import warnings

warnings.filterwarnings("ignore")
from Proposed_CWSA_based_HPCFH_Net.FuzzyLayer import FuzzyLayer
from Proposed_CWSA_based_HPCFH_Net.DefuzzyLayer import DefuzzyLayer
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
import numpy as np


def score_fuse(Score1, Score2, target, O_Data):
    Score1 = np.array(Score1)
    Score2 = np.array(Score2)

    Data = np.concatenate((Score1, Score2), axis=1)

    x_train, x_test, y_train, y_test = train_test_split(Data, target, train_size=0.9, random_state=123)
    n_c = len(np.unique(target))

    model = Sequential()
    model.add(FuzzyLayer(16, input_dim=len(x_train[0])))
    model.add(FuzzyLayer(32, input_dim=len(x_train[0])))
    model.add(Dense(n_c, activation='sigmoid'))
    model.add(DefuzzyLayer(1))

    model.compile(loss='logcosh', optimizer="Adam", metrics=['mae', 'acc'])
    model.fit(x_train, y_train, epochs=1000, verbose=0, batch_size=32)

    # Predict directly on x_test without unsafe resizing
    NF_pred = model.predict(x_test)
    pred = NF_pred
    Predicted = pred.astype("int")

    order_indices = Predicted.argsort()
    d_indices = order_indices[::-1]

    N = 10  # First 10 highest scored sentences
    d_indices = d_indices[:N]

    E_summary = []
    #  top-scoring sentences
    for idx in d_indices:
        E_summary.append(O_Data[idx])

    return E_summary